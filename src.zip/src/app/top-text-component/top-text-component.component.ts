
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'topText',
  templateUrl: './top-text-component.component.html',
  styleUrls: [ '../../css/responsive.css', '../../css/style.css']
})
export class TopTextComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
