import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-communities',
  templateUrl: './my-communities.component.html',
  styleUrls: ['./my-communities.component.css']
})
export class MyCommunitiesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
