import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main-post-view',
  templateUrl: './main-post-view.component.html',
  styleUrls: ['./main-post-view.component.css']
})
export class MainPostViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
