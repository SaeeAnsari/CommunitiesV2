export interface User{
    id: number,
    firstName: string,
    lastName: string,
    active: boolean,
    authenticationPortalID: number
}