export interface Message {
    id: number;
    userID: number;
    message: string,
    timestamp: Date
}   
